package com.ma7alak.dz;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import android.os.Build;
import android.os.Bundle;
import android.webkit.*;

public class MainActivity extends Activity {
    private WebView web;
    private ValueCallback<Uri[]> chooser;
    private static final String HOST = "mohammedaminemaou-bit.github.io";
    private static final String HOME = "https://mohammedaminemaou-bit.github.io/MA7ALEK-DZ/";
    private static final String CH = "ma7alak_alerts";

    private static final String POLYFILL =
        "(function(){if(window.__ntf)return;window.__ntf=1;"
      + "function N(t,o){try{AndroidNotify.show(String(t),String((o&&o.body)||''),String((o&&o.tag)||''))}catch(e){}}"
      + "N.permission=(function(){try{return AndroidNotify.granted()?'granted':'default'}catch(e){return 'default'}})();"
      + "N.requestPermission=function(cb){try{AndroidNotify.request()}catch(e){}N.permission='granted';if(cb)cb('granted');return Promise.resolve('granted')};"
      + "window.Notification=N;"
      + "if(window.ServiceWorkerRegistration){ServiceWorkerRegistration.prototype.showNotification=function(t,o){N(t,o);return Promise.resolve()}}"
      + "})();";

    public class Bridge {
        @JavascriptInterface public boolean granted() { return canNotify(); }
        @JavascriptInterface public void request() { runOnUiThread(() -> askPerm()); }
        @JavascriptInterface public void show(String title, String body, String tag) { notifyNow(title, body, tag); }
    }

    private boolean canNotify() {
        if (Build.VERSION.SDK_INT < 33) return true;
        return checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
    }
    private void askPerm() {
        if (Build.VERSION.SDK_INT >= 33 && !canNotify())
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 2);
    }
    private void notifyNow(String title, String body, String tag) {
        if (!canNotify()) return;
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        android.app.Notification.Builder nb;
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel(CH, "تنبيهات المحل", NotificationManager.IMPORTANCE_HIGH));
            nb = new android.app.Notification.Builder(this, CH);
        } else nb = new android.app.Notification.Builder(this);
        Intent i = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(this, 0, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        nb.setSmallIcon(R.mipmap.ic_launcher).setContentTitle(title).setContentText(body)
          .setStyle(new android.app.Notification.BigTextStyle().bigText(body))
          .setContentIntent(pi).setAutoCancel(true);
        nm.notify(tag == null || tag.isEmpty() ? (int) System.currentTimeMillis() : tag.hashCode(), nb.build());
    }


    private boolean online() {
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo ni = cm.getActiveNetworkInfo();
            return ni != null && ni.isConnected();
        } catch (Exception e) { return true; }
    }
    private String readAsset(String name) {
        try {
            InputStream in = getAssets().open(name);
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[8192]; int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            in.close();
            return out.toString("UTF-8");
        } catch (Exception e) { return null; }
    }
    private boolean fallbackLoaded = false;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        askPerm();
        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setCacheMode(online() ? WebSettings.LOAD_DEFAULT : WebSettings.LOAD_CACHE_ELSE_NETWORK);
        web.addJavascriptInterface(new Bridge(), "AndroidNotify");

        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageStarted(WebView v, String url, android.graphics.Bitmap f) { v.evaluateJavascript(POLYFILL, null); }
            @Override public void onPageFinished(WebView v, String url) { v.evaluateJavascript(POLYFILL, null); }
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if (HOST.equals(u.getHost())) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception e) {}
                return true;
            }
            @Override public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
                if (!r.isForMainFrame() || fallbackLoaded) return;
                String html = readAsset("index.html");
                if (html != null) {
                    fallbackLoaded = true;
                    v.loadDataWithBaseURL(HOME, html, "text/html", "utf-8", HOME);
                } else {
                    v.loadDataWithBaseURL(null,
                        "<html dir='rtl'><body style='font-family:sans-serif;text-align:center;padding:40px;background:#0C1F4A;color:#fff'>"
                        + "<h2>لا يوجد اتصال بالإنترنت</h2></body></html>", "text/html", "utf-8", null);
                }
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onPermissionRequest(final PermissionRequest r) {
                runOnUiThread(() -> r.grant(r.getResources()));
            }
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (chooser != null) chooser.onReceiveValue(null);
                chooser = cb;
                try { startActivityForResult(p.createIntent(), 1); }
                catch (Exception e) { chooser = null; return false; }
                return true;
            }
        });
        if (b == null) web.loadUrl(HOME); else web.restoreState(b);
    }

    @Override protected void onActivityResult(int req, int res, Intent d) {
        if (req == 1 && chooser != null) {
            chooser.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, d));
            chooser = null;
        }
    }
    @Override protected void onSaveInstanceState(Bundle b) { super.onSaveInstanceState(b); web.saveState(b); }
    @Override public void onBackPressed() { if (web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
